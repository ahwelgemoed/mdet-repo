export const MyFirstModule$List_Files_Node = async () => (await import("Z:/Documents/MendixApps/Mendix-Desktop-main/javascriptsource/myfirstmodule/actions/List_Files_Node")).List_Files_Node;
export const MyFirstModule$Write_File_Node = async () => (await import("Z:/Documents/MendixApps/Mendix-Desktop-main/javascriptsource/myfirstmodule/actions/Write_File_Node")).Write_File_Node;
export const MyFirstModule$Read_File_Node = async () => (await import("Z:/Documents/MendixApps/Mendix-Desktop-main/javascriptsource/myfirstmodule/actions/Read_File_Node")).Read_File_Node;
export const MyFirstModule$Get_String_Rust = async () => (await import("Z:/Documents/MendixApps/Mendix-Desktop-main/javascriptsource/myfirstmodule/actions/Get_String_Rust")).Get_String_Rust;
