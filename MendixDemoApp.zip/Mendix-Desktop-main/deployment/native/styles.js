import * as style0 from "Z:/Documents/MendixApps/Mendix-Desktop-main/themesource/anychart_buildingblocks/native/main";
import * as style1 from "Z:/Documents/MendixApps/Mendix-Desktop-main/themesource/nanoflowcommons/native/main";
import * as style2 from "Z:/Documents/MendixApps/Mendix-Desktop-main/themesource/webactions/native/main";
import * as style3 from "Z:/Documents/MendixApps/Mendix-Desktop-main/themesource/atlas_core/native/main";
import * as style4 from "Z:/Documents/MendixApps/Mendix-Desktop-main/themesource/myfirstmodule/native/main";
import * as style5 from "Z:/Documents/MendixApps/Mendix-Desktop-main/themesource/mysecondmodule/native/main";
import * as style6 from "Z:/Documents/MendixApps/Mendix-Desktop-main/theme/native/main";

import { flatten } from "mendix/native";

module.exports = flatten([style0, style1, style2, style3, style4, style5, style6]);
