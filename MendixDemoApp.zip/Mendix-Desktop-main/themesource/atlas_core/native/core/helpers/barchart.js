export const barChartSquare = {
    chart: {
        aspectRatio: 1
    }
};
export const barChartMaxSpace = {
    chart: {
        flex: 1,
        aspectRatio: undefined
    }
};
